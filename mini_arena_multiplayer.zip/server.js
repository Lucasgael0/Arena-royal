const http=require('http');
const fs=require('fs');
const path=require('path');
const WebSocket=require('ws');
const server=http.createServer((req,res)=>{
  const file=req.url==='/'?'/index.html':req.url;
  const p=path.join(__dirname,file);
  if(fs.existsSync(p)){res.writeHead(200,{'Content-Type':file.endsWith('.html')?'text/html':'text/plain'});res.end(fs.readFileSync(p))}
  else{res.writeHead(404);res.end('Not found')}
});
const wss=new WebSocket.Server({server});
const players={}; let next=1;
const obstacles=[{x:260,y:180,w:180,h:110},{x:650,y:150,w:220,h:100},{x:1080,y:210,w:190,h:120},{x:1420,y:150,w:180,h:100},{x:420,y:760,w:210,h:110},{x:940,y:760,w:220,h:110},{x:1330,y:700,w:230,h:120},{x:760,y:430,w:260,h:90},{x:1180,y:470,w:260,h:90}];
function blocked(x,y){return obstacles.some(o=>x>o.x-18&&x<o.x+o.w+18&&y>o.y-18&&y<o.y+o.h+18)}
function broadcast(o){let s=JSON.stringify(o);wss.clients.forEach(c=>c.readyState===1&&c.send(s))}
wss.on('connection',ws=>{
 let id='p'+next++; players[id]={id,name:'Jugador',x:150+Math.random()*1500,y:100+Math.random()*900,hp:100,ammo:30,a:0};
 ws.on('message',raw=>{
  let m;try{m=JSON.parse(raw)}catch{return}
  let p=players[id];if(!p)return;
  if(m.type==='join')p.name=String(m.name||'Jugador').slice(0,12);
  if(m.type==='move'){
   let dx=+m.dx||0,dy=+m.dy||0,n=Math.hypot(dx,dy)||1;
   let nx=p.x+dx/n*7,ny=p.y+dy/n*7;
   if(nx>20&&nx<1780&&!blocked(nx,p.y))p.x=nx;
   if(ny>20&&ny<1080&&!blocked(p.x,ny))p.y=ny;
   p.a=+m.a||0;
  }
  if(m.type==='shoot'&&p.ammo>0){
   p.ammo--; let b={x:p.x+Math.cos(m.a)*25,y:p.y+Math.sin(m.a)*25,vx:Math.cos(m.a)*15,vy:Math.sin(m.a)*15};
   broadcast({type:'bullet',b});
   setTimeout(()=>{for(let id2 in players){let q=players[id2];if(id2!==id&&Math.hypot(q.x-b.x,q.y-b.y)<28){q.hp-=25;if(q.hp<=0){q.hp=100;q.x=150+Math.random()*1500;q.y=100+Math.random()*900}}}},250);
  }
 });
 ws.on('close',()=>delete players[id]);
 ws.id=id;
});
setInterval(()=>{wss.clients.forEach(ws=>{if(ws.readyState===1)ws.send(JSON.stringify({type:'state',id:ws.id,players}))})},50);
server.listen(process.env.PORT||3000,()=>console.log('Mini Arena server running'));
