# Mini Arena Multiplayer

Juego pequeño tipo arena para navegador y teléfono.

## Ejecutar en una PC
1. Instala Node.js.
2. Abre una terminal en esta carpeta.
3. Ejecuta: `npm install`
4. Ejecuta: `node server.js`
5. En la PC abre `http://localhost:3000`.

## Jugar desde teléfonos
Los teléfonos deben poder acceder a la dirección donde esté alojado el servidor. Para jugar por internet, sube esta carpeta a un servicio que soporte Node.js/WebSocket. Luego cada teléfono abre la URL y usa la misma dirección del servidor.

Controles:
- PC: WASD para moverse y mouse para apuntar/disparar.
- Teléfono: esta versión incluye la interfaz base y está preparada para ampliarse con controles táctiles completos.
